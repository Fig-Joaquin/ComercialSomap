import { Router } from 'express';
import {
  createImagenProducto,
  getImagenesByProducto,
  deleteImagenProducto,
} from '../../controllers/productos/imagenProductoController';
import { authMiddleware, roleMiddleware } from '../../middleware/roleMiddleware';
import { upload } from '../../middleware/uploadMiddleware'; // Middleware para subir imágenes

// Creación de la variable router.
const router = Router();

router.get(
  '/producto/:id/imagenes',
  // roleMiddleware(['gerente', 'jefe_inventarista']),
  getImagenesByProducto
);

// // Que el router pase por el Middleware de verificacíon
//  router.use(authMiddleware);

// Rutas para manejar imágenes de productos
router.post(
  '/subir-imagen',
  roleMiddleware(['gerente', 'jefe_inventarista']), // Middleware de roles
  upload.single('imagen'), // Middleware para manejar la carga de una imagen
  createImagenProducto // Controlador para crear la imagen
);


router.delete(
  '/eliminar-imagen/:id',
  // roleMiddleware(['gerente', 'jefe_inventarista']),
  deleteImagenProducto
);

export default router;
